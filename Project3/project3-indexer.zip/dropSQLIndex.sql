DROP INDEX Location ON ItemLocations;

DROP TABLE ItemLocations;